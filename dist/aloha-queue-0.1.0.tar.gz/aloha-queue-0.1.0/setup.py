from setuptools import setup, find_packages

setup(
    name="aloha-queue",
    version="0.1.0",
    packages=find_packages(),
    author="Junle Yan",
    author_email="junleyan.hi@gmail.com",
    license="MIT"
)